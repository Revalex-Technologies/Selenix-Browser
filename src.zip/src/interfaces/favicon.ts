export interface IFavicon {
  url?: string;
  data?: string;
  _id?: string;
}
