import { WebContentsView, app, ipcMain } from 'electron';
import { parse as parseUrl } from 'url';
import { getViewMenu } from './menus/view';
import { AppWindow } from './windows';
import { IHistoryItem, IBookmark } from '~/interfaces';
import {
  ERROR_PROTOCOL,
  NETWORK_ERROR_HOST,
  WEBUI_BASE_URL,
} from '~/constants/files';
import { NEWTAB_URL } from '~/constants/tabs';
import {
  ZOOM_FACTOR_MIN,
  ZOOM_FACTOR_MAX,
  ZOOM_FACTOR_INCREMENT,
} from '~/constants/web-contents';
import { TabEvent } from '~/interfaces/tabs';
import { Queue } from '~/utils/queue';
import { Application } from './application';
import { getUserAgentForURL } from './user-agent';

interface IAuthInfo {
  url: string;
}

export class View {
  public webContentsView: WebContentsView;

  public isNewTab = false;
  public homeUrl: string;
  public favicon = '';
  public incognito = false;

  public errorURL = '';

  private hasError = false;

  private window: AppWindow;

  public bounds: any;

  public lastHistoryId: string;

  public bookmark: IBookmark;

  public findInfo = {
    occurrences: '0/0',
    text: '',
  };

  public requestedAuth: IAuthInfo;
  public requestedPermission: any;

  private historyQueue = new Queue();

  private lastUrl = '';

  // --- Auto-resize helpers for WebContentsView
  private _boundUpdateBounds?: () => void;
  private _resizeListenersAttached = false;

  public constructor(window: AppWindow, url: string, incognito: boolean) {
    const path = require('path');
    this.webContentsView = new WebContentsView({
      webPreferences: {
        // Construct the preload script path using path.join(). On Windows the
        // returned app path may contain backslashes, and string
        // concatenation could produce an invalid URI. Using path.join
        // normalises separators across platforms.
        preload: path.join(app.getAppPath(), 'build', 'view-preload.bundle.js'),
        nodeIntegration: false,
        contextIsolation: true,
        sandbox: true,
        partition: incognito ? 'view_incognito' : 'persist:view',
        plugins: true,
        webSecurity: true,
        javascript: true,
      },
    });

    // When using @electron/remote in renderers, each WebContents must be
    // explicitly enabled. The built-in remote module has been removed in
    // recent Electron versions, so without calling enable() the alias to
    // '@electron/remote' in the renderer will throw "@electron/remote cannot be
    // required in the browser process". Enabling the webContents makes the
    // remote APIs available in the corresponding renderer process. See
    // https://www.npmjs.com/package/@electron/remote/main for details.
    try {
      // Dynamically require to avoid importing @electron/remote/main in
      // environments where it might not be available (e.g. unit tests).
      const { enable } = require('@electron/remote/main');
      enable(this.webContentsView.webContents);
    } catch (err) {
      // If enabling fails, log the error but continue. The renderer will
      // gracefully handle missing remote APIs.
      console.warn('Failed to enable remote for browser view:', err);
    }

    this.incognito = incognito;

    this.webContents.userAgent = getUserAgentForURL(
      this.webContents.userAgent,
      '',
    );

    (this.webContents as any).windowId = window.win.id;

    this.window = window;
    this.homeUrl = url;

    this.webContents.session.webRequest.onBeforeSendHeaders(
      (details, callback) => {
        const { object: settings } = Application.instance.settings;
        if (settings.doNotTrack) details.requestHeaders['DNT'] = '1';
        callback({ requestHeaders: details.requestHeaders });
      },
    );

    ipcMain.handle(`get-error-url-${this.id}`, async (e) => {
      return this.errorURL;
    });

    this.webContents.on('context-menu', (e, params) => {
      const menu = getViewMenu(this.window, params, this.webContents);
      menu.popup();
    });

    this.webContents.addListener('found-in-page', (e, result) => {
      Application.instance.dialogs
        .getDynamic('find')
        .webContentsView.webContents.send('found-in-page', result);
    });

    this.webContents.addListener('page-title-updated', (e, title) => {
      this.window.updateTitle();
      this.updateData();

      this.emitEvent('title-updated', title);
      this.updateURL(this.webContents.getURL());
    });

    this.webContents.addListener('did-navigate', async (e, url) => {
      this.emitEvent('did-navigate', url);

      await this.addHistoryItem(url);
      this.updateURL(url);
    });

    this.webContents.addListener(
      'did-navigate-in-page',
      async (e, url, isMainFrame) => {
        if (isMainFrame) {
          this.emitEvent('did-navigate', url);

          await this.addHistoryItem(url, true);
          this.updateURL(url);
        }
      },
    );

    this.webContents.addListener('did-stop-loading', () => {
      this.updateNavigationState();
      this.emitEvent('loading', false);
      this.updateURL(this.webContents.getURL());
    });

    this.webContents.addListener('did-start-loading', () => {
      this.hasError = false;
      this.updateNavigationState();
      this.emitEvent('loading', true);
      this.updateURL(this.webContents.getURL());
    });

    
    // Ensure all window.open/_blank/new-window requests open as tabs, not new BrowserWindows.
    try {
      (this.webContents as any).setWindowOpenHandler?.((details: any) => {
        const url = details?.url || '';
        const frameName = (details as any)?.frameName || '';
        const disposition = (details as any)?.disposition || 'foreground-tab';
        try {
          if (disposition === 'background-tab') {
            this.window.viewManager.create({ url, active: false }, true);
          } else if (disposition === 'foreground-tab' || disposition === 'new-window') {
            this.window.viewManager.create({ url, active: true }, true);
          } else if (frameName === '_self') {
            this.window.viewManager.selected.webContents.loadURL(url);
          } else {
            // Default to opening in a new foreground tab.
            this.window.viewManager.create({ url, active: true }, true);
          }
        } catch (err) {
          // swallow errors and deny default
        }
        return { action: 'deny' };
      });
    } catch {}
this.webContents.addListener('did-start-navigation', async (e, ...args) => {
      this.updateNavigationState();

      this.favicon = '';

      this.emitEvent('load-commit', ...args);
      this.updateURL(this.webContents.getURL());
    });

    this.webContents.on(
      'did-start-navigation',
      (e, url, isInPlace, isMainFrame) => {
        if (!isMainFrame) return;
        const newUA = getUserAgentForURL(this.webContents.userAgent, url);
        if (this.webContents.userAgent !== newUA) {
          this.webContents.userAgent = newUA;
        }
      },
    );

    (this.webContents as any).addListener(
      'new-window',
      (e: any, url: string, frameName: string, disposition: string) => {
        if (disposition === 'new-window') {
          if (frameName === '_self') {
            e.preventDefault();
            this.window.viewManager.selected.webContents.loadURL(url);
          } else if (frameName === '_blank') {
            e.preventDefault();
            this.window.viewManager.create(
              {
                url,
                active: true,
              },
              true,
            );
          }
        } else if (disposition === 'foreground-tab') {
          e.preventDefault();
          this.window.viewManager.create({ url, active: true }, true);
        } else if (disposition === 'background-tab') {
          e.preventDefault();
          this.window.viewManager.create({ url, active: false }, true);
        }
      },
    );

    this.webContents.addListener(
      'did-fail-load',
      (e, errorCode, errorDescription, validatedURL, isMainFrame) => {
        // ignore -3 (ABORTED) - An operation was aborted (due to user action).
        if (isMainFrame && errorCode !== -3) {
          this.errorURL = validatedURL;

          this.hasError = true;

          this.webContents.loadURL(
            `${ERROR_PROTOCOL}://${NETWORK_ERROR_HOST}/${errorCode}`,
          );
        }
      },
    );

    this.webContents.addListener(
      'page-favicon-updated',
      async (e, favicons) => {
        this.favicon = favicons[0];

        this.updateData();

        try {
          let fav = this.favicon;

          if (fav.startsWith('http')) {
            fav = await Application.instance.storage.addFavicon(fav);
          }

          this.emitEvent('favicon-updated', fav);
        } catch (e) {
          this.favicon = '';
          // console.error(e);
        }
      },
    );

    this.webContents.addListener('zoom-changed', (e, zoomDirection) => {
      const newZoomFactor =
        this.webContents.zoomFactor +
        (zoomDirection === 'in'
          ? ZOOM_FACTOR_INCREMENT
          : -ZOOM_FACTOR_INCREMENT);

      if (
        newZoomFactor <= ZOOM_FACTOR_MAX &&
        newZoomFactor >= ZOOM_FACTOR_MIN
      ) {
        this.webContents.zoomFactor = newZoomFactor;
        this.emitEvent('zoom-updated', this.webContents.zoomFactor);
        window.viewManager.emitZoomUpdate();
      } else {
        e.preventDefault();
      }
    });

    this.webContents.addListener(
      'certificate-error',
      (
        event: Electron.Event,
        url: string,
        error: string,
        certificate: Electron.Certificate,
        callback: Function,
      ) => {
        console.log(certificate, error, url);
        // TODO: properly handle insecure websites.
        event.preventDefault();
        callback(true);
      },
    );

    this.webContents.addListener('media-started-playing', () => {
      this.emitEvent('media-playing', true);
    });

    this.webContents.addListener('media-paused', () => {
      this.emitEvent('media-paused', true);
    });

    if (url.startsWith(NEWTAB_URL)) this.isNewTab = true;

    this.webContents.loadURL(url);

    this._boundUpdateBounds = () => {
      try {
        if (!this.window?.win || this.window.win.isDestroyed()) return;
        const { x, y, width, height } = this.window.win.getContentBounds();
        // Fill the entire content area; ViewManager may later adjust via fixBounds().
        // Coerce to non-negative sane values to avoid exceptions on initial layout.
        const w = Math.max(0, width ?? 0);
        const h = Math.max(0, height ?? 0);
        (this.webContentsView as any).setBounds?.({ x: 0, y: 0, width: w, height: h });
      } catch (err) {
        // swallow layout errors; ViewManager will still correct bounds.
      }
    };

    const winRef = this.window.win;
    // Attach a few key window events
    const attachResizeListeners = () => {
      if (this._resizeListenersAttached) return;
      this._resizeListenersAttached = true;
      winRef.on('resize', this._boundUpdateBounds!);
      winRef.on('enter-full-screen', this._boundUpdateBounds!);
      winRef.on('leave-full-screen', this._boundUpdateBounds!);
      winRef.on('maximize', this._boundUpdateBounds!);
      winRef.on('unmaximize', this._boundUpdateBounds!);
      // Do an initial sizing pass.
      this._boundUpdateBounds!();
    };
    attachResizeListeners();
  }

  public get webContents() {
    return this.webContentsView.webContents;
  }

  public get url() {
    return this.webContents.getURL();
  }

  public get title() {
    return this.webContents.getTitle();
  }

  public get id() {
    return this.webContents.id;
  }

  public get isSelected() {
    return this.id === this.window.viewManager.selectedId;
  }

  public updateNavigationState() {
    if (this.webContentsView.webContents.isDestroyed()) return;

    if (this.window.viewManager.selectedId === this.id) {
      this.window.send('update-navigation-state', {
        canGoBack: this.webContents.navigationHistory.canGoBack(),
        canGoForward: this.webContents.navigationHistory.canGoForward(),
      });
    }
  }

  public destroy() {
    // Remove auto-resize bindings to avoid leaks
    try {
      if (this._boundUpdateBounds && this.window?.win && !this.window.win.isDestroyed()) {
        this.window.win.removeListener('resize', this._boundUpdateBounds);
        this.window.win.removeListener('enter-full-screen', this._boundUpdateBounds);
        this.window.win.removeListener('leave-full-screen', this._boundUpdateBounds);
        this.window.win.removeListener('maximize', this._boundUpdateBounds);
        this.window.win.removeListener('unmaximize', this._boundUpdateBounds);
      }
    } catch {}
    this._resizeListenersAttached = false;
    this._boundUpdateBounds = undefined;

    try {
      if (this.webContentsView && (this.webContentsView as any).webContents) {
        const wc: any = (this.webContentsView as any).webContents;
        if (typeof wc.isDestroyed === 'function') {
          if (!wc.isDestroyed()) wc.destroy();
        } else if (typeof wc.destroy === 'function') {
          wc.destroy();
        }
      }
    } catch {}
    this.webContentsView = null as any;
  }

  public async updateCredentials() {
    if (
      !process.env.ENABLE_AUTOFILL ||
      this.webContentsView.webContents.isDestroyed()
    )
      return;

    const item = await Application.instance.storage.findOne<any>({
      scope: 'formfill',
      query: {
        url: this.hostname,
      },
    });

    this.emitEvent('credentials', item != null);
  }

  public async addHistoryItem(url: string, inPage = false) {
    if (
      url !== this.lastUrl &&
      !url.startsWith(WEBUI_BASE_URL) &&
      !url.startsWith(`${ERROR_PROTOCOL}://`) &&
      !this.incognito
    ) {
      const historyItem: IHistoryItem = {
        title: this.title,
        url,
        favicon: this.favicon,
        date: new Date().getTime(),
      };

      await this.historyQueue.enqueue(async () => {
        this.lastHistoryId = (
          await Application.instance.storage.insert<IHistoryItem>({
            scope: 'history',
            item: historyItem,
          })
        )._id;

        historyItem._id = this.lastHistoryId;

        Application.instance.storage.history.push(historyItem);
      });
    } else if (!inPage) {
      await this.historyQueue.enqueue(async () => {
        this.lastHistoryId = '';
      });
    }
  }

  public updateURL = (url: string) => {
    if (this.lastUrl === url) return;

    this.emitEvent('url-updated', this.hasError ? this.errorURL : url);

    this.lastUrl = url;

    this.isNewTab = url.startsWith(NEWTAB_URL);

    this.updateData();

    if (process.env.ENABLE_AUTOFILL) this.updateCredentials();

    this.updateBookmark();
  };

  public updateBookmark() {
    this.bookmark = Application.instance.storage.bookmarks.find(
      (x) => x.url === this.url,
    );

    if (!this.isSelected) return;

    this.window.send('is-bookmarked', !!this.bookmark);
  }

  public async updateData() {
    if (!this.incognito) {
      const id = this.lastHistoryId;
      if (id) {
        const { title, url, favicon } = this;

        this.historyQueue.enqueue(async () => {
          await Application.instance.storage.update({
            scope: 'history',
            query: {
              _id: id,
            },
            value: {
              title,
              url,
              favicon,
            },
            multi: false,
          });

          const item = Application.instance.storage.history.find(
            (x) => x._id === id,
          );

          if (item) {
            item.title = title;
            item.url = url;
            item.favicon = favicon;
          }
        });
      }
    }
  }

  public send(channel: string, ...args: any[]) {
    this.webContents.send(channel, ...args);
  }

  public get hostname() {
    return parseUrl(this.url).hostname;
  }

  public emitEvent(event: TabEvent, ...args: any[]) {
    this.window.send('tab-event', event, this.id, args);
  }
}
