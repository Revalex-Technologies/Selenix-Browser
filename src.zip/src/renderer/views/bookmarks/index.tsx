import App from './components/App';
import { renderWebUI } from '~/utils/webui-entry';
renderWebUI(App);
