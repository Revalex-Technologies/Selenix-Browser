import '~/renderer/window-controls-overlay';
import App from './components/App';
import { renderUI } from '~/utils/ui-entry';
renderUI(App);
