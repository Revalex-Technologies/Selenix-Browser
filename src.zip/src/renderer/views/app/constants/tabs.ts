export const TAB_MAX_WIDTH = 240;
export const TAB_MIN_WIDTH = 72;
export const TAB_PINNED_WIDTH = 40;
export const TAB_ANIMATION_DURATION = 200;
export const TABS_PADDING = 2;
