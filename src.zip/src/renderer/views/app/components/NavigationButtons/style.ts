import styled from 'styled-components';

export const StyledContainer = styled.div`
  display: flex;
  -webkit-app-region: no-drag;
  align-items: center;
`;
