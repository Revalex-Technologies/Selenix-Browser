import styled, { css } from 'styled-components';

export const StyledBrowserAction = styled.div`
  position: relative;
`;
